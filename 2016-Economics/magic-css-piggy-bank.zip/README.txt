A Pen created at CodePen.io. You can find this one at http://codepen.io/bphillips201/pen/drxcj.

 Insert coin